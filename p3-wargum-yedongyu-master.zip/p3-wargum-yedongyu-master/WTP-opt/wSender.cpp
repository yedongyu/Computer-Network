#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <iostream>
#include <chrono>
#include <ctime>
#include <fstream>
#include <unordered_map>
#include <vector>
#include <chrono>
#include <ctime>
#include <deque>
#include <assert.h>
#include <stdlib.h>     
#include <sys/time.h> 
#include <cstring>
#include <sstream>     
#include "crc32.h"
#include "PacketHeader.h"

using namespace std;

#define PACKET_LENGTH 1472
#define DATA_LENGTH 1456
#define TIME_OUT 500

struct record {
    timeval time;
	char* packet;
	int index;     
	bool received;   // 0: no ack; 1: received ack
};

void encode(PacketHeader* header, char * buf) {
    memcpy(buf , (char*)&(header->type), 4);
	memcpy(buf + 4 , (char*)&(header->seqNum), 4);
	memcpy(buf + 8 , (char*)&(header->length), 4);
	memcpy(buf + 12 , (char*)&(header->checksum), 4);
}

void decode(PacketHeader * header, char * buf) {
	memcpy((char*)&(header->type), buf, 4);
	memcpy((char*)&(header->seqNum), buf + 4, 4);
	memcpy((char*)&(header->length), buf + 8, 4);
	memcpy((char*)&(header->checksum), buf + 12, 4);
}

//Send begin or send end message
void setConnection(int sockfd, ofstream& fout, bool start_end, struct sockaddr_in serv_addr) {
    //send the message
    srand(time(NULL));
    PacketHeader header;
    if(start_end) header.type = 0;
    else header.type = 1;
    header.seqNum = rand();  
    header.length = 0;   
    header.checksum = 0; 

    struct  timeval    tv1;
    struct  timezone   tz1;
    struct  timeval    tv2;
    struct  timezone   tz2;
    socklen_t addrlen;

	addrlen=sizeof(serv_addr);

    char send_buffer[PACKET_LENGTH];
    memset(send_buffer, '\0', PACKET_LENGTH);

    encode(&header, send_buffer);
    // if(send(sockfd, send_buffer, PACKET_LENGTH, 0) == -1) {
    //     cout << "cannot send\n";
    //     exit(0);
    // }
    if (sendto(sockfd, send_buffer, PACKET_LENGTH, 0, (struct sockaddr *)&serv_addr, addrlen) < 0) {
        cout << "sendto failed\n";
        exit(1);
    }
    fout << header.type << " " << header.seqNum << " " << header.length << " "<< header.checksum <<endl;

    //receive the ack
    char receive_buffer[PACKET_LENGTH];
    memset(receive_buffer, '\0', PACKET_LENGTH);
    gettimeofday(&tv1,&tz1);
    while(1) {
        memset(receive_buffer, '\0', PACKET_LENGTH);
        // if(recv(sockfd, receive_buffer, PACKET_LENGTH , 0) < 0) {
        //     cout << "cannot rec ack\n";
        //     exit(0);
        // } 
        if(recvfrom(sockfd, receive_buffer, PACKET_LENGTH , MSG_DONTWAIT, (struct sockaddr *)&serv_addr, &addrlen) < 0) {
            if (errno != EAGAIN && errno != EWOULDBLOCK) {
				cout << "cannot rec ack\n";
				exit(1);
			}
        }
        else {

            PacketHeader ack;
            decode(&ack, receive_buffer);
            fout << ack.type << " " << ack.seqNum << " " << ack.length << " " << ack.checksum << endl;
            if (ack.type == 3 && ack.seqNum == header.seqNum) {
				break;
			}
        }
        gettimeofday(&tv2,&tz2);
        if((tv2.tv_sec * 1000000 + tv2.tv_usec - tv1.tv_sec * 1000000 - tv1.tv_usec) >= (500 * 1000)) {
                // if(send(sockfd, send_buffer, PACKET_LENGTH, 0) == -1) {
                //     cout << "cannot send\n";
                //     exit(0);
                // }
                if (sendto(sockfd, send_buffer, PACKET_LENGTH, 0, (struct sockaddr *)&serv_addr, addrlen) < 0) {
                    cout << "sendto failed\n";
                    exit(1);
                }
                fout << header.type << " " << header.seqNum << " " << header.length  << " " << header.checksum <<endl;
                gettimeofday(&tv1,&tz1);
        }
    }
}

//Send the dqta 
void getData(int move_size, deque<record*>& window, ifstream& fin, int& seqNum) {
    char data[DATA_LENGTH];
    for(int i = 0; i < move_size; i++) {
        fin.read(data, DATA_LENGTH);
        int length = fin.gcount();
        if(length <= 0) {
            return;
        }
        PacketHeader header;
        header.type = 2; 
        header.seqNum = seqNum++;
        header.length = length;
        header.checksum = crc32(data, length);
        char* packet = new char[PACKET_LENGTH];
		memset(packet, '\0', PACKET_LENGTH);
        encode(&header, packet);
        for(int j = 0; j < length; j++) {
            packet[j + 16] = data[j];
        } 
        record* new_record=new record();
        new_record->packet=packet;
		new_record->index=header.seqNum;
		new_record->received=false;
        window.push_back(new_record);
    }
}

void sendData(int sockfd, deque<record*>& window, ofstream& fout, int start, struct sockaddr_in serv_addr) {
    struct  timeval    tv1;
    struct  timezone   tz1;
    socklen_t addrlen;

	addrlen=sizeof(serv_addr);
    for(int i = start; i < window.size(); i++) {
        // if(send(sockfd, window[i]->packet, PACKET_LENGTH, 0) == -1) {
        //     cout << "cannot send\n";
        //     exit(0);
        // }; 
        if (sendto(sockfd, window[i]->packet, PACKET_LENGTH, 0, (struct sockaddr *)&serv_addr, addrlen) < 0) {
            cout << "sendto failed\n";
            exit(1);
        }
        gettimeofday(&tv1,&tz1);
        window[i]->time = tv1;
        PacketHeader header;
        decode(&header, window[i]->packet);
        fout << header.type << " " << header.seqNum << " " << header.length << " "<< header.checksum <<endl;
    }
}


void sendSingleData(int sockfd, deque<record*>& window, ofstream& fout, ifstream& fin, int& seqNum, struct sockaddr_in serv_addr) {
    char data[DATA_LENGTH];
    fin.read(data, DATA_LENGTH);
    int length = fin.gcount();
    if(length <= 0) {
        return;
    }
    socklen_t addrlen;

	addrlen=sizeof(serv_addr);
    PacketHeader header;
    header.type = 2; 
    header.seqNum = seqNum++;
    header.length = length;
    header.checksum = crc32(data, length);
    //char packet[PACKET_LENGTH];
    char* packet = new char[PACKET_LENGTH];
    memset(packet, '\0', PACKET_LENGTH);
    encode(&header, packet);
    for(int j = 0; j < length; j++) {
        packet[j + 16] = data[j];
    } 
    record* new_record=new record();
    new_record->packet=packet;
    new_record->index=header.seqNum;
    new_record->received=false;
    struct  timeval    tv1;
    struct  timezone   tz1;
    // if(send(sockfd, packet, PACKET_LENGTH, 0) == -1) {
    //     cout << "cannot send\n";
    //     exit(0);
    // }; 
    if (sendto(sockfd, packet, PACKET_LENGTH, 0, (struct sockaddr *)&serv_addr, addrlen) < 0) {
        cout << "sendto failed\n";
        exit(1);
    }   
    gettimeofday(&tv1,&tz1);
    new_record->time = tv1;
    window.push_back(new_record);
    fout << header.type << " " << header.seqNum << " " << header.length << " "<< header.checksum <<endl;
}

int main(int argc, char* argv[]) {
    // handle all the argv
    ifstream fin;
    fin.open(argv[1]);
    if(!fin) {
        cout << "can not open the file\n";
        exit(0);
    }
    int window_size = atoi(argv[2]);
    ofstream fout;
	fout.open(argv[3]);
    if(!fout) {
        cout << "can not log the file\n";
        exit(0);
    }
    string rec_ip = argv[4];
    int rec_port = atoi(argv[5]);
    
    
    //set the connection
    int sockfd, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;  
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        cout << "ERROR opening socket\n";
        exit(0);
    }
    server = gethostbyname(argv[4]);
    if (server == NULL) {
        cout << "ERROR, no such host\n";
        exit(0);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(rec_port);
    // if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0) {
    //     cout << "ERROR connecting\n";
    //     exit(0);
    // }
    socklen_t addrlen;

	addrlen=sizeof(serv_addr);
    int seqNum = 0;
    int startNum = 0;
    deque<record*> window;
    //deque<timeval> time_window;
    int move_size = 0;
    struct  timeval    tv1;
    struct  timezone   tz1;
    //sendBeginMessage
    setConnection(sockfd, fout, true, serv_addr);
    //sendData
    getData(window_size, window, fin, seqNum);
    sendData(sockfd, window, fout, 0,  serv_addr);

    char receive_buffer[PACKET_LENGTH];
    memset(receive_buffer, '\0', PACKET_LENGTH);
    while(1) {
        memset(receive_buffer, '\0', PACKET_LENGTH);
        // if(recv(sockfd, receive_buffer, PACKET_LENGTH , 0) < 0) {
        //     cout << "cannot rec ack\n";
        //     exit(1);
        // } 
        if(recvfrom(sockfd, receive_buffer, PACKET_LENGTH , MSG_DONTWAIT, (struct sockaddr *)&serv_addr, &addrlen) < 0) {
            if (errno != EAGAIN && errno != EWOULDBLOCK) {
				cout << "cannot rec ack\n";
				exit(1);
			}
        }
        else {
            PacketHeader ack;
            decode(&ack, receive_buffer);
            fout << ack.type << " " << ack.seqNum << " " << ack.length << " " << ack.checksum << endl;
            if (ack.type == 3) {
                if(ack.seqNum == window[0]->index) {
                    window[0]->received = true;
                    while(window[0]->received) {
                        //delete old;
                        delete [] window[0]->packet;
                        delete window[0];
                        window.pop_front();
                        //get New 
                        sendSingleData(sockfd, window, fout, fin, seqNum, serv_addr);
                        if(window.size() == 0) {
                            break;
                        }
                    }
                } else {
                    if(ack.seqNum > window[0]->index && ack.seqNum < window[0]->index + window_size) {
                        window[ack.seqNum - window[0]->index]->received = true;
                    }
                }
			}
        }
        if(window.size() == 0) {
            break;
        }
        for (int i = 0; i < window.size(); i++){
			if(window[i]->received==false){
                gettimeofday(&tv1,&tz1);
				if (tv1.tv_sec * 1000000 + tv1.tv_usec - window[i]->time.tv_sec * 1000000- window[i]->time.tv_usec >= (500 * 1000)) {
					PacketHeader header;
					decode(&header, window[i]->packet);
					// if (send(sockfd, window[i]->packet, PACKET_LENGTH, 0) < 0) {
					// 	cout << "cannot send\n";
					// 	exit(1);
					// }
                    if (sendto(sockfd, window[i]->packet, PACKET_LENGTH, 0, (struct sockaddr *)&serv_addr, addrlen) < 0) {
                        cout << "sendto failed\n";
                        exit(1);
                    }
					fout << header.type << " " << header.seqNum << " " << header.length << " " << header.checksum << endl;
					window[i]->time = tv1;				
				}
			}
		}
    }
    //sendEndMessage
    setConnection(sockfd, fout, false,  serv_addr);
    close(sockfd);
    return 0;
}