#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <iostream>
#include <fstream>
#include <deque>
#include "crc32.h"
#include "PacketHeader.h"

#define CHUNCK_SIZE 1456
#define PACKET_SIZE 1472

using namespace std;
//总览：Receiver will only serve one client and while serving, it will ignore the start message from others connections. The function of the receiver is to store the file received correctly.
//The files shold be name as FILE-i and i is the index of clients

void *get_in_addr(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}
//structure of packetheader
//struct PacketHeader {
//    unsigned int type;     // 0: START; 1: END; 2: DATA; 3: ACK
//    unsigned int seqNum;   // Described below
//    unsigned int length;   // Length of data; 0 for ACK, START and END packets
//    unsigned int checksum; // 32-bit CRC
//    PacketHeader();
//    PacketHeader(int x,int y,int w,int z):type(x),seqNum(y),length(w),checksum(z) {};   //constructor
//    ~PacketHeader();  //deconstructor
//};
//struture of packet sending to Sender,actually it is NULL in Receiver side
struct Content{
 char *content;
 int length;
 
};


//write header message to buffer
void header_return(char *buffer,PacketHeader *header){
 memcpy(buffer , (char*)&(header->type), 4);
 memcpy(buffer + 4 , (char*)&(header->seqNum), 4);
 memcpy(buffer + 8 , (char*)&(header->length), 4);
 memcpy(buffer + 12 , (char*)&(header->checksum), 4);
}

//get header message from buffer
void buffer_to_header(char *buffer,PacketHeader *header){
 memcpy((char*)&header->type,buffer,4);
 memcpy((char*)&header->seqNum,buffer+4,4);
 memcpy((char*)&header->length,buffer+8,4);
 memcpy((char*)&header->checksum,buffer+12,4);
}
void get_content(char *buffer,PacketHeader *header, char *chunk){
 buffer_to_header(buffer,header);
 if (header->length == 0) {
  return;
 }
 buffer+=16;
 for(int i=0;i<header->length;i++){
  //cout<<*buffer<<" ";
  *chunk++=*buffer++;
 }
}
//Receiver
int main(int argc,char *argv[]){
 if(argc!=5){
  cout<<"Error number of input arguments"<<endl;
 }else{
  int sockfd;
  struct addrinfo hints, *serverinfo,*cur;
  char *portnum=argv[1];
  int maxwin_size=atoi(argv[3]);
  ofstream flog;
  ofstream ffile;
  string FILE_DIR;
        flog.open(argv[2]);
        FILE_DIR = argv[4];
  char sender_ip[INET6_ADDRSTRLEN];
  char buf_return[PACKET_SIZE];

        bzero(&hints, sizeof (hints));
        hints.ai_flags=AI_PASSIVE;     //用于绑定端口
        hints.ai_family=AF_UNSPEC;     //可以使用IPv6 或者IPv4
        hints.ai_socktype=SOCK_DGRAM;   //使得 返回的是适用于数据报套接口的信息，既支持UDP也支持TCP

        //绑定第一个可行的连接
        int res;
        if(res=getaddrinfo(NULL,portnum,&hints,&serverinfo)<0){
         fprintf(stderr, "%s\n", gai_strerror(res));
         exit(1);
        }
        for (cur = serverinfo; cur != NULL; cur = cur->ai_next) {
        if ((sockfd = socket(cur->ai_family, cur->ai_socktype,cur->ai_protocol)) == -1) {
    perror("listener: socket");
    continue;
   }
   
   if(::bind(sockfd, cur->ai_addr, (cur->ai_addrlen))==-1){
    close(sockfd);
    perror("Error binding");
    continue;
   }
   break;
     }

     if (cur == NULL) {
   fprintf(stderr, "listener: failed to bind socket\n");
   return 2;
  }
     //释放指针
     freeaddrinfo(serverinfo);

     cout<<"Waiting for packets..."<<endl;
     //定义内容接收buffer
     char buf_content[CHUNCK_SIZE];
     //定义接收带有MTP表头的buffer，UDP和IP表头已经被去掉了
     char buf_packet[PACKET_SIZE];
     //记录表头信息
     PacketHeader loggingInfo;
     //移动接收窗口
     deque<Content> win_move;
     bool inconnection=false;
     int ACK=0;

     string FILENAME;
     int file_ind=1;
     //记录当前对方的IP地址
     memset(sender_ip, '\0', INET6_ADDRSTRLEN);
     char tmpIP[INET6_ADDRSTRLEN];
     while(true){
      struct sockaddr_storage server_addr;                 //通用结构体，能放下IPv6，调用socket API时，需要将struct sockaddr_storage强制类型转换为struct sockaddr，地址长度为sizeof(struct sockaddr_storage)
      socklen_t addrlen;

      addrlen=sizeof(server_addr);
      memset(buf_packet,'\0',PACKET_SIZE);
      if(recvfrom(sockfd,buf_packet,PACKET_SIZE,0,
       (struct sockaddr*)&server_addr,&addrlen)<1){
       perror("Error when receiving");
       exit(1);
      }
      memset(buf_content,'\0',CHUNCK_SIZE);
      get_content(buf_packet,&loggingInfo,buf_content);
      flog << loggingInfo.type <<' '<<loggingInfo.seqNum<<' '<< loggingInfo.length <<' '<< loggingInfo.checksum <<endl;
      if(crc32(buf_content,loggingInfo.length)!=loggingInfo.checksum){
       continue;
      }else{
       memset(tmpIP, '\0', INET6_ADDRSTRLEN);
       inet_ntop(server_addr.ss_family, get_in_addr((struct sockaddr *)&server_addr), tmpIP, sizeof(tmpIP));

       PacketHeader response;
       if(loggingInfo.type==0){
        if(!inconnection){
         //生成写回的表头
         
         response.type=3;       //表示ACK
         response.seqNum=loggingInfo.seqNum;      //ACK=seq+1
         response.length=0;
         response.checksum=0;
         inconnection=true;
         strcpy(sender_ip, tmpIP);
         //生成内容文件
         //FILENAME="FILE-"+to_string(file_ind++);
         //ffile.open(FILE_DIR+"FILE-"+to_string(file_ind++),ofstream::binary);
         ffile.open(FILE_DIR+"/FILE-"+to_string(file_ind++));
         //cout<<FILE_DIR+"/FILE-"+to_string(file_ind)<<endl;
         if(!ffile){
          cout<<"Can not open file"<<endl;
          exit(1);
         }
        }else if(strcmp(sender_ip, tmpIP)==0){
         response.type=3;       //表示ACK
         response.seqNum=loggingInfo.seqNum;      //ACK=seq+1
         response.length=0;
         response.checksum=0;
        }else{
         continue;
        }
       }
       else if(loggingInfo.type==1){
        response.type = 3;
     response.seqNum = loggingInfo.seqNum;
     response.length = 0;
     response.checksum = 0;
        if(strcmp(sender_ip, tmpIP)==0){
         inconnection=false;
         ACK=0;
      memset(tmpIP,'\0',sizeof(tmpIP));
      ffile.close();
        }
       }
       else if(loggingInfo.type==2){
        //别的IP发来的数据，丢弃
        //cout<<sender_ip<<"   aaa   "<<tmpIP<<endl;
        //cout<<loggingInfo.seqNum;
        if(strcmp(sender_ip,tmpIP)!=0) {
         //cout<<"dd"<<endl;
         continue;
        }
     if(loggingInfo.seqNum >=ACK+ maxwin_size){
      //cout<<"cc"<<endl;
         continue;
        }

        else if(loggingInfo.seqNum>=ACK){
         //cout<<"cc"<<endl;
         for(int i=win_move.size();i<=loggingInfo.seqNum-ACK;i++){
          Content pdata;
          pdata.length = 0;
       pdata.content = NULL;
          win_move.push_back(pdata);
         }
         char *newData = new char[CHUNCK_SIZE];
      for (int i = 0; i < loggingInfo.length; i++) {
       newData[i] = buf_content[i];
      }
         win_move[loggingInfo.seqNum-ACK].content=newData;
         //cout<<loggingInfo.seqNum-ACK<<"Content"<<endl;
         win_move[loggingInfo.seqNum-ACK].length=loggingInfo.length;

         if(ACK==loggingInfo.seqNum){
          //cout<<win_move[0]->content<<"HIO"<<endl;
          while(!win_move.empty() && win_move[0].content!=NULL){
           //写入内容
           //cout<<"HI there"<<endl;
           ACK++;
           
           ffile.write(win_move.front().content,win_move.front().length);
           delete [] win_move[0].content;
           win_move.pop_front();
          }
         }
        }
        //写表头信息；
        //cout<<"  aaa  "<<ACK<<endl;
        //cout<<ACK<<endl;
        response.type=3;
        response.seqNum=ACK;
        response.length=0;
        response.checksum=0;

        
       }else{
        continue;
       }
       
       memset(buf_return,'\0',PACKET_SIZE);
       header_return(buf_return,&response);
       int num;
       if ((num = sendto(sockfd, buf_return, PACKET_SIZE, 0,
     (struct sockaddr *)&server_addr, addrlen)) == -1) {
      perror("error response to sender");
      exit(1);
    }
    
                flog << response.type <<' '<<response.seqNum<<' '<< response.length <<' '<< response.checksum <<endl;
      }
     }
 }
 return 0;
}