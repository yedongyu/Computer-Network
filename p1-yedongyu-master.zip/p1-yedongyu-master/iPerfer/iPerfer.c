#include <stdio.h>
#include <time.h> 
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/time.h> 
int main(int argc, char *argv[]){
    if(strcmp(argv[1],"-s")==0){
        server(argc,argv);
    }else if(strcmp(argv[1],"-c")==0){
        client(argc,argv);
    }
}
void error(char *msg)
{
    perror(msg);
    exit(1);
}
int client(int argc, char *argv[])
{
    if (argc != 8) {
       fprintf(stderr,"Error: missing or additional arguments\n");
       exit(0);
    }
    char buffer[1000];
    bzero(buffer,1000);
    int cnt=0;
    int sockfd, portno, n;
    float rate;
    double realtime;
    struct sockaddr_in serv_addr;
    struct hostent *server;
    struct  timeval    tv1;
    struct  timezone   tz1;
    struct  timeval    tv2;
    struct  timezone   tz2;
    int time=atoi(argv[7]);
    
    if(atoi(argv[5])<1024 || atoi(argv[5])>65535){
        fprintf(stderr,"Error: port number must be in the range [1024, 65535]\n");
        exit(0);
     }
    portno = atoi(argv[5]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening socket");
    server = gethostbyname(argv[3]);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(portno);
    if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0) 
        error("ERROR connecting");
    
    n = send(sockfd,buffer,1000, 0);
    gettimeofday(&tv1,&tz1);
    cnt++;
    while(1){
        gettimeofday(&tv2,&tz2);
        if(tv2.tv_sec>=tv1.tv_sec+time) break;
        n = send(sockfd,buffer,1000,0);
        if (n < 0) 
             error("ERROR writing to socket");
        cnt++;
    }
    n= send(sockfd,"1",1000,0);
    if (n < 0)  error("ERROR writing to socket");
    n=recv(sockfd,buffer,1000, MSG_WAITALL);
    if(buffer[0]=='1') {
        gettimeofday(&tv2,&tz2);
        close(sockfd);
    }
    realtime = (tv2.tv_sec - tv1.tv_sec);
    //realtime += (tv2.tv_usec - tv1.tv_usec) / 1000000.0;  
    double c=cnt;
    rate=(8.0*(c))/realtime/1000;
    printf("Sent=%d KB, rate=%.3f Mbps",cnt,rate);
        
    return 0;
}
int server(int argc, char *argv[])
{
     int sockfd, newsockfd, portno, clilen;
     char buffer[1000];
     bzero(buffer,1000);
     struct sockaddr_in serv_addr, cli_addr;
     int n=0;
     int cnt=0;
     float rate;
     double realtime;
    struct  timeval    tv1;
    struct  timezone   tz1;
    struct  timeval    tv2;
    struct  timezone   tz2;

     if (argc != 4) {
         fprintf(stderr,"Error: missing or additional arguments\n");
         exit(1);
     }
     if(atoi(argv[3])<1024 || atoi(argv[3])>65535){
        fprintf(stderr,"Error: port number must be in the range [1024, 65535]\n");
        exit(1);
     }
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0) 
        error("ERROR opening socket");
     bzero((char *) &serv_addr, sizeof(serv_addr));
     portno = atoi(argv[3]);
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;
     serv_addr.sin_port = htons(portno);
     if (bind(sockfd, (struct sockaddr *) &serv_addr,
              sizeof(serv_addr)) < 0) 
              error("ERROR on binding");
     listen(sockfd,5);
     clilen = sizeof(cli_addr);
     newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
     if (newsockfd < 0) 
        error("ERROR on accept");
    n = recv(newsockfd,buffer,1000, MSG_WAITALL);
    gettimeofday(&tv1,&tz1);
    cnt++;
     while(1){
        n = recv(newsockfd,buffer,1000, MSG_WAITALL);
        if (n < 0) error("ERROR reading from socket");
        if(buffer[0] == '1') {
            break;
        }
        cnt++;
     }
     gettimeofday(&tv2,&tz2);
     n = send(newsockfd, buffer, 1000, 0);
     if (n < 0) error("ERROR writing to socket");
     close(sockfd);
    close(newsockfd);
    
    double c = cnt;
    realtime = (tv2.tv_sec - tv1.tv_sec);
    //realtime += (tv2.tv_usec - tv1.tv_usec) / 1000000.0;  
    rate=(8*(c))/realtime/1000;
    printf("Received=%d KB, rate=%f Mbps",cnt,rate);
    
    return 0; 
}