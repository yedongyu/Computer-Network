#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <cassert>
#include <unordered_map>
#include <queue>
#include "DNSHeader.h"
#include "DNSQuestion.h"
#include "DNSRecord.h"
using namespace std;

int round_robin(int argc, char* argv[])
{
    //get all the ip address
    vector<string> ips;
    int index = 0;
    string ip;
    ifstream fin;
    fin.open(argv[4]);
    if (!fin.is_open()) {
        cout << "open failed\n";
        exit(1);
    }
    while (fin >> ip) {
        ips.push_back(ip);
    }

	ofstream fout;
	fout.open(argv[1]);
    //connect 
    int sockfd, newsockfd, portno;

   
    struct sockaddr_in serv_addr, cli_addr;
     
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
   
    if (sockfd < 0) {
        cout << "ERROR opening socket\n";
    }
        

    bzero((char *) &serv_addr, sizeof(serv_addr));
    
    portno = atoi(argv[2]);

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);


    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)  {
        cout << "ERROR on binding\n";
    }

    listen(sockfd,5);

    while(true) {

        socklen_t clilen = sizeof(cli_addr);
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

        
        char *client_ip_c = inet_ntoa(cli_addr.sin_addr);
        string client_ip = string(client_ip_c);

       
        if (newsockfd < 0) {
            cout << "ERROR on accept\n";
        }

        
        int buf_len_header;
        if (recv(newsockfd, &buf_len_header, 4, MSG_WAITALL) < 0) {
        	cout << "ERROR recv length of header\n";
        }
        int len_header = ntohl(buf_len_header);
        char buf_header[len_header];
        
        if (recv(newsockfd, buf_header, len_header, MSG_WAITALL) < 0) {
        	cout << "ERROR recv header\n";
        }

        
        int buf_len_question;
        if (recv(newsockfd, &buf_len_question, 4, MSG_WAITALL) < 0) {
        	cout << "ERROR recv length of question\n";
        }
        int len_question = ntohl(buf_len_question);
        
        char buf_question[len_question];
        
        if (recv(newsockfd, buf_question, len_question, MSG_WAITALL) < 0) {
        	cout << "ERROR recv question\n";
        }

        string s_header(buf_header);
        string s_question(buf_question);
        DNSHeader header;
        header = header.decode(s_header);
        DNSQuestion question;
        question = question.decode(s_question);


        header.AA = 1;

        DNSRecord record;
        
        if (strcmp(question.QNAME, "video.cse.umich.edu") != 0) {
        	cout << "test" << endl;
            header.RCODE = 3;
        } else {
            string ip = ips[index];
            index = (index + 1) % (int) ips.size();
                
            if (ip.empty()) {
                header.RCODE = 3;
            } else {
                header.RCODE = 0;
                strcpy(record.NAME, question.QNAME);
                record.TYPE = 1;
                record.CLASS = 1;
                record.TTL = 0;
                record.RDLENGTH = 4;
                strcpy(record.RDATA, ip.c_str());
                
            }
        }
            
        string str_header = header.encode(header);
        
        string str_record = record.encode(record);
        
        uint32_t header_len = htonl(str_header.size());
        
        char se_buf_header[str_header.size()];
        
        memset(se_buf_header, 0, str_header.size());
        
        for(int i=0;i<str_header.size();i++){
        	se_buf_header[i]=str_header[i];
        }
       
        uint32_t record_len = htonl(str_record.size());
 
        char se_buf_record[str_record.size()];
        
        for(int i=0;i<str_record.size();i++){
        	se_buf_record[i]=str_record[i];
        }


        
        if (send(newsockfd, &header_len, 4, 0) < 0) {
        	cout << "ERROR send length of header\n";
        }
       

        if (send(newsockfd, se_buf_header, str_header.size(), 0) < 0) {
        	cout << "ERROR send header\n";
        }

        if (send(newsockfd, &record_len, 4, 0) < 0) {
        	cout << "ERROR send length of record\n";
        }
        

        if (send(newsockfd, se_buf_record, str_record.size(), 0) < 0) {
        	cout << "ERROR send record\n";
        }
     


        close(newsockfd);
              // write log
        fout << client_ip << '\t' << question.QNAME << '\t' << ip << endl;
        cout << client_ip << '\t' << question.QNAME << '\t' << ip << endl;


    }
   

    close(sockfd);
    fout.close();
    return 0; 
}


struct comp {
	bool operator()(const pair<int, int> &p1, const pair<int, int> &p2) {
		return p1.second > p2.second;
	}
};

int geographic_distance(int argc, char* argv[]) {


    vector<string> ips;
	vector<string> types;
	unordered_map<string, int> id_table;
	unordered_map<int, vector<pair<int, int> > > network; // first is id, second is cost
    pair<int, int> id_cost;
    

    int nodes_num;
    int links_num; 
    int id; 
    int start; 
    int end;
    int cost;
    string t_ip;
    string type;
    string temp;

	ifstream fin;
	fin.open(argv[4]);
    if (!fin.is_open()) {
        cout << "open failed" << endl;
        exit(1);
    }
		
	fin >> temp >> nodes_num;
	for (int i = 0; i < nodes_num; i++) {
        fin >> id >> type >> t_ip;
        ips.push_back(t_ip);
        types.push_back(type);
        id_table[t_ip] = i;
	}

	fin >> temp;
	fin >> links_num;
    for (int i = 0; i < links_num; i++) {
        fin >> start >> end >> cost;
        network[start].push_back(make_pair(end, cost));
        network[end].push_back(make_pair(start, cost));
    }

	ofstream fout;
	fout.open(argv[1]);
    //connect 
    int sockfd, newsockfd, portno;

   
    struct sockaddr_in serv_addr, cli_addr;
     
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
   
    if (sockfd < 0) {
        cout << "ERROR opening socket\n";
    }
        

    bzero((char *) &serv_addr, sizeof(serv_addr));
    
    portno = atoi(argv[2]);

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);


    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)  {
        cout << "ERROR on binding\n";
    }

    listen(sockfd,5);

    while(true) {
        socklen_t clilen = sizeof(cli_addr);
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

        char *client_ip_c = inet_ntoa(cli_addr.sin_addr);
        string client_ip = string(client_ip_c);

       
        if (newsockfd < 0) {
            cout << "ERROR on accept\n";
        }

        
        int buf_len_header;
        if (recv(newsockfd, &buf_len_header, 4, MSG_WAITALL) < 0) {
        	cout << "ERROR recv length of header\n";
        }
        int len_header = ntohl(buf_len_header);
        char buf_header[len_header];
        
        if (recv(newsockfd, buf_header, len_header, MSG_WAITALL) < 0) {
        	cout << "ERROR recv header\n";
        }

        int buf_len_question;
        if (recv(newsockfd, &buf_len_question, 4, MSG_WAITALL) < 0) {
        	cout << "ERROR recv length of question\n";
        }
        int len_question = ntohl(buf_len_question);
        
        char buf_question[len_question];
        
        if (recv(newsockfd, buf_question, len_question, MSG_WAITALL) < 0) {
        	cout << "ERROR recv question\n";
        }

        string s_header(buf_header);
        string s_question(buf_question);
        DNSHeader header;
        header = header.decode(s_header);
        DNSQuestion question;
        question = question.decode(s_question);


        header.AA = 1;
        string ip = "";
        DNSRecord record;
        if (strcmp(question.QNAME, "video.cse.umich.edu") != 0) {
            header.RCODE = 3;
        } else {
            
            priority_queue<pair<int, int>, vector<pair<int, int> >, comp> pq;
            vector<bool> visited(ips.size(), false);
            int start_id = id_table[client_ip];      
            pair<int, int> p = make_pair(start_id, 0);
            pair<int, int> cur, next;

            pq.push(p);
            while (!pq.empty()) {
                cur = pq.top();
                pq.pop();
                if (visited[cur.first]) {
                    continue;
                }
                visited[cur.first] = true;

                if (types[cur.first] == "SERVER") {
                    ip = ips[cur.first];
                    
                    break;
                }

                for (pair<int, int> next_node : network[cur.first]) {
                    // avoid clients and visited switches added to the queue
                    if (visited[next_node.first] || types[next_node.first] == "CLIENT") {
                        continue;
                    }
                    next.first = next_node.first;
                    next.second = cur.second + next_node.second;
                    pq.push(next);
                }
            }

            /////
            
            if (ip.empty()) {
                header.RCODE = 3;
            } else {
                header.RCODE = 0;
                strcpy(record.NAME, question.QNAME);
                record.TYPE = 1;
                record.CLASS = 1;
                record.TTL = 0;
                record.RDLENGTH = 4;
                strcpy(record.RDATA, ip.c_str());
            }
        }

            
        string str_header = header.encode(header);
        string str_record = record.encode(record);
        
     
        uint32_t header_len = htonl(str_header.size());
        
        char se_buf_header[str_header.size()];
        
        memset(se_buf_header, 0, str_header.size());
        
        for(int i=0;i<str_header.size();i++){
        	se_buf_header[i]=str_header[i];
        }

        
	
        uint32_t record_len = htonl(str_record.size());
 
        char se_buf_record[str_record.size()];
        
        for(int i=0;i<str_record.size();i++){
        	se_buf_record[i]=str_record[i];
        }
        
        if (send(newsockfd, &header_len, 4, 0) < 0) {
        	cout << "ERROR send length of header\n";
        }
       
        if (send(newsockfd, se_buf_header, str_header.size(), 0) < 0) {
        	cout << "ERROR send header\n";
        }

        if (send(newsockfd, &record_len, 4, 0) < 0) {
        	cout << "ERROR send length of record\n";
        }

        if (send(newsockfd, se_buf_record, str_record.size(), 0) < 0) {
        	cout << "ERROR send record\n";
        }

        close(newsockfd);
              // write log
        fout << client_ip << '\t' << question.QNAME << '\t' << ip << endl;
        cout << client_ip << '\t' << question.QNAME << '\t' << ip << endl;

    }
   
    close(sockfd);
    fout.close();
    return 0; 
}

int main(int argc, char* argv[]) 
{
    if(atoi(argv[3]) == 0) {
        round_robin(argc, argv);
    } else {
        geographic_distance(argc, argv);
    }
    return 0;
}