#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <sys/select.h>
#include <vector>
#include <algorithm>
#include <cassert>
#include <sys/time.h> 
#include <errno.h>
#include <cstdio>
#include <unordered_map>
#include "DNSHeader.h"
#include "DNSQuestion.h"
#include "DNSRecord.h"

using namespace std;
static int len_of_buffer=8192;




string get_value(string str, string key) {
    int key_index = str.find(key);
    int space_index = str.find(' ', key_index);
    int end = str.find('\n', key_index);
    return str.substr(space_index + 1, end - space_index - 1);
}

string recv_response(int server_sd){
    string data = "";
    char buf;
    while(1) {
        int bytesRecvd = recv(server_sd, &buf, 1, 0);
        
        if (bytesRecvd < 0)
        {
            printf("%s %d\n", __FUNCTION__, __LINE__);
            perror("recv");
            exit(-1);
        }

        data += buf;
        if (data.size() >= 4) {
            if(data.substr(data.size() - 4) == "\r\n\r\n")
            {
            	//cout<<"get it"<<endl;
            	break;
            }
        }
    }

    int content_len = atoi(get_value(data, "Content-Length").c_str());
   
    if(content_len>0){
    	char response[content_len];
	    if (recv(server_sd, response, content_len, MSG_WAITALL) < 0) {
			 
	        exit(1);
	    }
	    data += string(response);
    }
    
    return data;
   

}
string proxy_to_DNS(char *dns_ip,int dns_port){
	
	int dns_sd = socket(AF_INET, SOCK_STREAM, 0);
		
    if (dns_sd  < 0) {
    	
		cout << "Error on ip socket" << endl;
		exit(1);
	}
	struct sockaddr_in dns_addr;
	memset(&dns_addr, 0, sizeof(dns_addr));
    dns_addr.sin_family  = AF_INET;
    dns_addr.sin_port = htons(dns_port);
    dns_addr.sin_addr.s_addr = inet_addr(dns_ip);
    
    if (connect(dns_sd, (struct sockaddr *) &dns_addr, sizeof(dns_addr)) < 0) 
	{
		
		cout << "Error on dns connect" << endl;
		exit(1);
	}
	DNSHeader header;
	DNSQuestion question;
	DNSRecord record;
	

	header.ID = 1;
	header.QR = 0;
	header.OPCODE = 1;
	header.AA = 0;
	header.TC = 0;
	header.RD = 0;
	header.RA = 0;
	header.Z = 0;
	header.RCODE = 0;
	header.QDCOUNT = 1;
	header.ANCOUNT = 0;
	header.NSCOUNT = 0;
	header.ARCOUNT = 0;
	string header_msg=header.encode(header);
	
	strcpy(question.QNAME, "video.cse.umich.edu");
	question.QTYPE = 1;
	question.QCLASS = 1;
	string question_msg=question.encode(question);
	
	uint32_t len1=htonl(header_msg.size());
	uint32_t len2=htonl(question_msg.size());
	
	
	char to_send3[8096];
	char to_send4[8096];
	for(int i=0;i<header_msg.size();i++){
		to_send3[i]=header_msg[i];
	}
	for(int i=0;i<question_msg.size();i++){
		to_send4[i]=question_msg[i];
	}
	

	if(send(dns_sd,&len1,4,0)<0){      //header的长度
		cout<<"Error in sending to DNS server"<<endl;
		exit(1);
	}
	if(send(dns_sd,to_send3,header_msg.size(),0)<0){     //header的内容
		cout<<"Error in sending to DNS server"<<endl;
		exit(1);
	}
	if(send(dns_sd,&len2,4,0)<0){     //question的长度
		cout<<"Error in sending to DNS server"<<endl;
		exit(1);
	}
	if(send(dns_sd,to_send4,question_msg.size(),0)<0){     //question的内容
		cout<<"Error in sending to DNS server"<<endl;
		exit(1);
	}
	//接收返回header的长度和内容
	
	int buf_len_header;
	if (recv(dns_sd,&buf_len_header,4, MSG_WAITALL) < 0) {
		cout << "Error on Recving length of response header\n";
	}

	
	int len3 = ntohl(buf_len_header);
	
	char to_recv2[len3];
	if(recv(dns_sd,to_recv2,len3,MSG_WAITALL) < 0) {
		cout << "Error on Recving response header\n";
	}
	string header_recv(to_recv2);
	DNSHeader header_return;
	header_return=header_return.decode(header_recv);
	
	//接收返回record的长度和内容
	
	int buf_len_record;
	if (recv(dns_sd,&buf_len_record,4,MSG_WAITALL) < 0) {
		cout << "Error on Recving the length of response record\n";
	}
	
	int len4 = ntohl(buf_len_record);
	
	char to_recv4[len4];
	if(recv(dns_sd,to_recv4,len4,MSG_WAITALL) < 0) {
		cout << "Error on Recving the response record\n";
	}
	string record_recv;
	for(int i=0;i<len4;i++){
		record_recv+=to_recv4[i];
	}

	DNSRecord record_return;
	record_return=record_return.decode(record_recv);
	string tmpwebIP(record_return.RDATA);    //获取IP地址
	
	close(dns_sd);
	return tmpwebIP;
}
//定义一个browser端的structure
struct proxy{
	int fd;
	proxy *web_response;    //由用户端的请求决定web端返回的是什么文件
	char http_request[8192];
	int browser_fd;
	int proxy_webserver_sd;
	struct timeval start_receive;
	struct timeval end_receive;
	bool proxy_to_web;
	bool isf4m;
	bool ischunck;
	bool first_f4m;
	int total_received;
	int content_length;
	double avg_throughput;
	string server_ip;
	string browser_ip;
	char chunk_name[50];
	int bitrate;
	vector<int> bitrate_vector;
	proxy(string cli_ip,int bd,string IP,int sd,bool k,int w,double p){
		fd=w;
		proxy_to_web=k;
		browser_ip=cli_ip;
		browser_fd=bd;
		server_ip=IP;
		proxy_webserver_sd=sd;
		first_f4m=true;
		total_received=0;
		avg_throughput=p;
	}
	//~proxy();
};

//需要定义 proxy 接收root server 内容的buffer， 需要定义proxy接收DNS内容的buffer， 需要定义proxy接收用户内容的buffer
int main(int argc, char *argv[]){
	if(argc>=6){
		
		char *rootname;   //web服务器名字
		string tmpwebIP;
		

		if(argc==7){
			rootname=argv[6];
			
		}
		else if(argc==6){
			char name[]="video.cse.umich.edu";
			rootname=name;
		}else{
			cout<<"The number of arguments are not valid"<<endl;
		}
		ofstream fout;
        fout.open(argv[1]);

        
    	double alpha=atof(argv[2]);
    	int server_port=atoi(argv[3]);
    	char *dns_ip=argv[4]; 
    	int dns_port=atoi(argv[5]);



    	//proxy 创建自己的socket(面向浏览器的sd)
    	// Bind server to sd and set up listen server
		int listen_browser_sd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if(listen_browser_sd<0){
			cout << "Error in opening TCP socket\n";
			return -1;
		}
		struct sockaddr_in self;
		memset(&self, 0, sizeof (self));
		self.sin_family = AF_INET;
		self.sin_addr.s_addr = INADDR_ANY;
		self.sin_port = htons((u_short) server_port);
		int err = bind(listen_browser_sd, (struct sockaddr*) &self, sizeof(self));
		if(err == -1)
		{
			cout << "Error binding the socket to the port number"<<endl;
			return 1;
		}

		err = listen(listen_browser_sd, 10);
		if(err == -1)
		{
			cout << "Error setting up listen queue"<<endl;
			return 1;
		}

		//定义浏览器方面的地址结构，初始化
		struct sockaddr_in browser_addr;
		memset(&browser_addr, 0, sizeof (browser_addr));		
		socklen_t browser_addr_len = sizeof(browser_addr);

		//定义文件句柄，用来跟踪每个用户是否有设置句柄，有的话证明用户连接上proxy
		fd_set read_set;
		//定义一个用户的集合，所有连接的用户都会放进这个集合里面
		vector<proxy*> fds;
 
		while(true){
			//定义最大的fd，用于select
			int maxfd = 0;
			//初始化文件句柄
			FD_ZERO(&read_set);
			//初始化面向浏览器的sd
			FD_SET(listen_browser_sd, &read_set);

			//loop 每次都把用户的文件句柄设置为0，这样才能检测到之后的新的连接,但是里面的其他内容是保留的
			for(int i=0;i<fds.size();i++){
				FD_SET(fds[i]->fd,&read_set);
				if(fds[i]->fd>maxfd){
					maxfd=fds[i]->fd;
				}
			}
			//找出最的的maxfd
			maxfd=max(maxfd,listen_browser_sd);
			//定义select函数，允许多个browsers可以连接到一个proxy，maxfd+1 很重要
			int number_fd = select(maxfd + 1, &read_set, NULL, NULL, NULL);

			//如果有新用户连接，listen_browser_sd会被设置，proxy检测到后会接收browser的连接，如果没有新用户，旧用户一直保持连接，listen_browser_sd不会被设置

			if(FD_ISSET(listen_browser_sd, &read_set)){
				//定义连接到proxy的用户的sd
				//获取browser的IP地址
                             
				int browser_sd=accept(listen_browser_sd, (struct sockaddr *) &browser_addr, &browser_addr_len);

				if(browser_sd == -1)
				{
					cout << "Error on accept" << endl;
				}else{
					//如果浏览器方面没有指定webserver的域名，使用默认域名

					if(argc==6){

						tmpwebIP=proxy_to_DNS(dns_ip,dns_port);   //参数还没确定
						
					}else if(strlen(argv[6])== 0) {
					 	tmpwebIP=proxy_to_DNS(dns_ip,dns_port); 
					}
					else{
						
						tmpwebIP=rootname;
						
					}
					//连接到webserver，使用关键函数 getaddrinfo(IP,port,hints,要填充的地址结构)
					struct addrinfo hints; 
				    struct addrinfo* result; 
				    memset(&hints, 0, sizeof (hints));
				    hints.ai_family = AF_INET;    
				    hints.ai_socktype = SOCK_STREAM; 
				    hints.ai_flags = AI_PASSIVE;     
				    if (getaddrinfo(tmpwebIP.c_str(), "80", &hints, &result) < 0)  //把上面返回的IP和80端口信息填到result里面
				    {
				        cout << "Error on getaddrinfo" << endl;
						return -1;
				    }
				    int proxy_webserver_sd;
				    if((proxy_webserver_sd = socket(result->ai_family, result->ai_socktype,result->ai_protocol))<0)
				    {
				        cout << "Error on client to server socket" << endl;
						return -1;
				    }

				    if(connect (proxy_webserver_sd, result->ai_addr, result->ai_addrlen) == -1){
				    	cout<<"Error on connect to webserver"<<endl;
				    }
				    //把用户添加进vector
				    char *browser_ip=inet_ntoa(browser_addr.sin_addr);
				    
				    proxy *cur_client2;
				    
				    cur_client2=new proxy(browser_ip,browser_sd,tmpwebIP,proxy_webserver_sd,true,proxy_webserver_sd,0.0);
					proxy *cur_client1=new proxy(browser_ip,browser_sd,tmpwebIP,proxy_webserver_sd,false,browser_sd,0.0);  //记录浏览器端的ip,sd，webserver端的ip,sd,并且面向browser
					cur_client1->web_response=cur_client2;
					cur_client2->web_response=cur_client1;

					fds.push_back(cur_client1);
					fds.push_back(cur_client2);



				}
			}
				
		    //分别读取有连接的用户的请求（格式：：/path/to/video/500Seg2-Frag3），根据这个请求向web服务器拿数据
		    for(int i=0;i<fds.size();i++){

		    	if(FD_ISSET(fds[i]->fd, &read_set)){

		    		char buffer[len_of_buffer];  //开头定义：len_of_buffer=1KB
		    		bzero(buffer,len_of_buffer);
					int blen=len_of_buffer;
					int bytesreceived;
					
					if(fds[i]->isf4m && fds[i]->proxy_to_web){
						string response = recv_response(fds[i]->fd);
						for(int k = 0; k < response.size(); k++) {
							buffer[k] = response[k];
						}
						bytesreceived = response.size();
					}else{
						bytesreceived=recv(fds[i]->fd,&buffer,blen,0);
					}
					
					
					
					if(bytesreceived<0){
						cout << "Error recving bytes" << endl;
						cout << strerror(errno) << endl;
						exit(1);
					}else if(bytesreceived==0){
						
						cout << "Connection closed" << endl;
						fds.erase(fds.begin() + i);
						i=i-1;
					}
					//现在要分析用户数据，修改bitrate，更新throughput
					if(!fds[i]->proxy_to_web){     //browser 端传来的数据
						char *f4m;
						char *chunk;
						chunk=strcasestr(buffer,"-Frag");
						f4m=strcasestr(buffer,".f4m");

						//修改bitrate字段
						if(f4m!=NULL){
							fds[i]->isf4m=true;
							fds[i]->web_response->isf4m=true;
							fds[i]->ischunck=false;
							fds[i]->web_response->ischunck=false;
							memcpy(fds[i]->http_request,buffer,bytesreceived);
							memcpy(fds[i]->web_response->http_request,buffer,bytesreceived);
							
						}
						else if (chunk!=NULL) // chunk type
						{
							
							fds[i]->ischunck=1;
							fds[i]->web_response->ischunck=1;
							fds[i]->isf4m=0;
							fds[i]->web_response->isf4m=0;
							//select bitrate
							int bitrate_browser=10;
							if(fds[i]->web_response->bitrate_vector.size()==0)
							{
								
								cout << "no bitrate in vector" <<endl;
							}
							else //vector has element
							{ 
								float bitrate_constraint=(fds[i]->web_response->avg_throughput)/1.5;
								if (fds[i]->web_response->bitrate_vector[0]>=bitrate_constraint)
								{	
									bitrate_browser=fds[i]->web_response->bitrate_vector[0];								 		
								}
								else
								{	
									for (int j = 0; j < fds[i]->web_response->bitrate_vector.size(); ++j)
									{
										if (fds[i]->web_response->bitrate_vector[j]<bitrate_constraint)
										{
											bitrate_browser=fds[i]->web_response->bitrate_vector[j];
										}
										else 
										{											
											break;
										}
									}
								}
							}
							
							fds[i]->bitrate=bitrate_browser;
							
							fds[i]->web_response->bitrate=bitrate_browser;
							char * replace_bitrate_pointer_left;
							char * replace_bitrate_pointer_right;
							char * chunk_name_pointer_right;
							replace_bitrate_pointer_left=strstr(buffer,"Seg");
							replace_bitrate_pointer_right=strstr(buffer,"Seg");
							while(*replace_bitrate_pointer_left!='/')
							{
								replace_bitrate_pointer_left=replace_bitrate_pointer_left-1;	
							}
							replace_bitrate_pointer_left=replace_bitrate_pointer_left+1;
							chunk_name_pointer_right=strstr(replace_bitrate_pointer_right," ");
							strncpy(fds[i]->web_response->chunk_name,replace_bitrate_pointer_left,(chunk_name_pointer_right-replace_bitrate_pointer_left));
							*replace_bitrate_pointer_left='\0';
							char buffer_again[len_of_buffer];
							bzero(buffer_again,len_of_buffer);
							snprintf(buffer_again,len_of_buffer,"%s%d%s",buffer,bitrate_browser,replace_bitrate_pointer_right);
							memcpy(buffer,buffer_again,strlen(buffer_again));							
							//timer start
							gettimeofday(&fds[i]->start_receive, NULL);
							fds[i]->web_response->start_receive=fds[i]->start_receive;
							
						}
						else{
							fds[i]->ischunck=false;
							fds[i]->isf4m=false;
							
						}
					
						if(send(fds[i]->proxy_webserver_sd,buffer,bytesreceived,0)==-1){
							
							cout << "error in browser send to server" <<endl;
                        	return -1;
						} 
					}
					else{   //webserver 端传来的数据
						if(strstr(buffer,"\r\n\r\n")!=NULL){
			    			char *body=strstr(buffer,"\r\n\r\n");

	                		//parse
		                	char *content_length_start=strstr(buffer,"Content-Length: ");
		                	char *content_length_end=strstr(content_length_start,"\r\n");
		                	char content_length[25];
		                	strncpy(content_length,(content_length_start+16),(content_length_end-content_length_start-16));  //Content-Length: 的长度是16
		                	content_length[(content_length_end-content_length_start-16)]='\0';		   
		                	fds[i]->content_length=atoi(content_length);
		                	fds[i]->total_received=bytesreceived;
			    			if(fds[i]->isf4m){
			    				if(fds[i]->first_f4m){   //f4m 文件中含有bitrate信息
			    					if(fds[i]->total_received>fds[i]->content_length){   //当所有f4m文件收到，把bitrate记录
			    						char* xml_pointer;
			                		 	char* media_pointer;
			                		 	char* bitrate_pointer;
			                			xml_pointer=strstr(body,"<?xml");
			                			media_pointer=strstr(xml_pointer,"<media");
			                			while(media_pointer!=NULL)
			                			{
			                				bitrate_pointer=strstr(media_pointer,"bitrate=");
			                				if (bitrate_pointer!=NULL)
			                				{
			                					int bitrate;
			                					if (sscanf(bitrate_pointer,"bitrate=\"%d\"", &bitrate)>=1)
			                					{
			                													
			                						fds[i]->bitrate_vector.push_back(bitrate);
			                						
			                					}
			                				}
			                				media_pointer=strstr(media_pointer+1,"<media");			                							                				
			                			}			  
			                			fds[i]->first_f4m=0;  
				    				}
				    				
				    				char* replace_f4m_pointer;
		                			replace_f4m_pointer=strstr(fds[i]->http_request,".f4m");
		                			int total_len=strlen(fds[i]->http_request);
		                			int before_len=replace_f4m_pointer-fds[i]->http_request;
		                			int after_len=total_len-before_len;
		                			memmove(replace_f4m_pointer+12,replace_f4m_pointer+5,after_len);
		                			memmove(replace_f4m_pointer,"_nolist.f4m ",strlen("_nolist.f4m "));
		                			
		                			if (send(fds[i]->browser_fd, buffer,bytesreceived, 0)== -1)						
										{
					                    	cout << "error in server send to browser" <<endl;
					                        return -1;
					                    } 
		       
			    				}
			    				else{   //没有需要修改的字段，直接送给browser就行
				    				if (send(fds[i]->browser_fd, buffer,bytesreceived , 0)== -1)						
									{
				                    	cout << "error in server send to browser" <<endl;
				                        return -1;
				                    }
			    				}
			    			}else{   //没有需要修改的字段，直接送给browser就行
			    				if (send(fds[i]->browser_fd, buffer,bytesreceived , 0)== -1)						
								{
			                    	cout << "error in server send to browser" <<endl;
			                        return -1;
			                    }
			    			}
			    		}else{     //header 后面的内容
			    			if(fds[i]->ischunck){
			    				fds[i]->total_received+=bytesreceived;
			    				if(fds[i]->total_received > fds[i]->content_length){
			    					gettimeofday(&fds[i]->end_receive, NULL);
		                			double elapsedTime = (fds[i]->end_receive.tv_sec - fds[i]->start_receive.tv_sec);
			    					elapsedTime += (fds[i]->end_receive.tv_usec - fds[i]->start_receive.tv_usec) / 1000000.0;
		                			double new_throughput=(fds[i]->content_length)*8/(elapsedTime*1000);//kb/s
		                			fds[i]->avg_throughput=alpha*new_throughput+(fds[i]->avg_throughput)*(1-alpha);
		                			
                                    fout << fds[i]->web_response->browser_ip.c_str() << " " << elapsedTime << " " << new_throughput << " " << fds[i]->avg_throughput << " " <<fds[i]->web_response->bitrate << " " << fds[i]->server_ip.c_str() << " " << fds[i]->chunk_name << endl;
		                			
			    				}
			    				if (send(fds[i]->browser_fd, buffer,bytesreceived , 0)== -1)						
								{
			                    	cout << "error in server send to browser" <<endl;
			                        return -1;
			                    }
			    			}else{
			    				if (send(fds[i]->browser_fd, buffer,bytesreceived , 0)== -1)						
								{
			                    	cout << "error in server send to browser" <<endl;
			                        return -1;
			                    }
			    			}
			    		}
					}
		    	}
		    }
		}
               fout.close();
	}
	else{
		cout << "Error: missing arguments" <<endl;
	}
        
	return 0;
}
